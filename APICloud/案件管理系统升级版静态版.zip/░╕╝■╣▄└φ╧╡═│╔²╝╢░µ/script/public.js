/**
 * Created by Administrator on 2017/6/16.
 */
const host = "http://172.16.8.122:8088";  // 测试服务器地址，调试的时候使用
//var host = "http://test.helpyouworkeasy.com:8080/case/";  // 测试服务器地址，调试的时候使用
//var host = "http://oa.hhm-ipr.com/"; // 客户正式地址，调试的时候不能使用
//通用的ready方法
function apiready1(){}
apiready=function(){
    if(document.getElementsByTagName('header')[0]){ /*判断是否为win是否固定头部padding*/
        $api.fixStatusBar(document.getElementsByTagName('header')[0]);
    }
    api.parseTapmode();
    api.setStatusBarStyle({
        style: 'light',
        color: '#CD2F2E'
    });
    if(api.winName=="root"||api.winName=="sign_in"){
        exitApp();
    }else{
        api.addEventListener({
            name: 'keyback'
        }, function (ret, err) {
            closeWin();
        });
    }
    apiready1();
    $("header .aui-pull-left").on("click",function(){closeWin()})
};
/* 打开新窗口*/
function openWin(name,url,pageParam,reload){
    api.openWin({
        name: name,
        url: url||'./public_win.html',
        pageParam: pageParam||{},//pageParam 传递参数 格式 json字符串 例子{}
        reload:reload||false,//）页面已经打开时，是否重新加载页面，重新加载页面后 apiready 方法将会被执行
        hScrollBarEnabled:false,//是否显示水平滚动条
        slidBackEnabled: false//是否支持滑动返回
    });
}
/*关闭窗口*/
function closeWin(name){
    if(name){
        api.closeWin({
            name:name
        });
    }else{
        api.closeWin();
    }
}
//打开frame
function openFrame(rect,pageParam,reload){
    var name=api.winName.slice(0,-4)+"_frm";
    api.openFrame({
        name: name,
        url: name+".html",
        bounces: false,//页面是否弹动
        rect:{ x: rect.x||0,
            y: rect.y||0,
            w: rect.w||'auto',
            h: rect.h||'auto'
        },
        pageParam:pageParam||{},
        hScrollBarEnabled:false,
        reload:reload||false
    })
}
//打开登录
function signIn(){
    api.openWin({
        name: 'sign_in',
        url: 'widget://html/sign_in.html',
        pageParam: {},//pageParam 传递参数 格式 json字符串 例子{}
        reload:true,//）页面已经打开时，是否重新加载页面，重新加载页面后 apiready 方法将会被执行
        hScrollBarEnabled:false,//是否显示水平滚动条
        slidBackEnabled: false,//是否支持滑动返回
        animation:{
            type:"none",                //动画类型（详见动画类型常量）
            subType:"from_left",       //动画子类型（详见动画子类型常量）
            duration:300                //动画过渡时间，默认300毫秒
        }
    });
}
//运行window中的函数
function runExecScript(fn,Win,Frm){
    api.execScript({
        name: Win||'root',
        frameName:Frm||"",
        script: fn
    });
}
//api.ajax方法封装
function sAjax(url,data,callback){
    var sid=$api.getStorage('JSESSIONID');
    if ( sid && sid != '' ) {
        var n=url.indexOf("?");
        url=url.slice(0,n)+(";jsessionid="+sid)+url.slice(n,url.length);
    }
    //var ajax = this;
    //ajax.callback = callback;
    //检查网络配置
    if(api.connectionType == 'none'){
        alert("请检查网络配置");
        return;
    }
    api.ajax({
        url: host+url,
        method: "post",
        timeout: 50,
        dataType: "json",
        headers: "application/x-www-form-urlencoded;charset=utf-8",
        returnAll: false,
        data: {
            values: data
        }
    },function(ret, err){
        //api.hideProgress();
        if(ret){
            //ajax.callback(ret);
            callback(ret);
        }else{
            alert(JSON.stringify(err.msg))
        }
    });
}
/*主题tab组件-基于zepto*/
function themeTap(){
    $(".theme_tab").on("click",".theme_tab_item a",function(e){
        var $el=$(this).parent("li");
        if($el.hasClass("active")){
            return
        }else{
            $el.addClass("active").siblings("li").removeClass("active");
            $($(this).attr("href")).addClass("active").siblings().removeClass("active");
        }
        e.preventDefault();
    })
}
//退出APP
function exitApp(){
    doubleClickExitApp();//双击静默退出
    //clickConfigExitApp();//单击确认退出
    //clickDefaultExitApp();//单击静默退出
}
//双击静默退出
function doubleClickExitApp(){
    api.addEventListener({//点击返回按钮事件（硬件）
        name: 'keyback'
    }, function(ret, err){
        api.toast({
            msg: '再按一次返回键退出'+api.appName,
            duration:2000,
            location: 'middle'
        });
        api.addEventListener({
            name: 'keyback'
        }, function(ret, err){
            api.closeWidget({
                id: api.appId, //这里改成自己的应用ID
                silent: true,//描述：（可选项）是否静默退出应用，只在主 widget 中有效。当为 false 时，引擎会弹出对话框询问是否退出应用
                retData: {name:'closeWidget'},
                animation: {
                    type: 'flip',
                    subType: 'from_bottom',
                    duration: 500
                }
            });
        });
        setTimeout(function(){
            doubleClickExitApp();
        },2000)
    });
}
//单击静默退出
function clickDefaultExitApp(){
    api.addEventListener({
        name: 'keyback'
    }, function(ret, err){
        api.closeWidget({
            id: api.appId, //这里改成自己的应用ID
            silent: true,//描述：（可选项）是否静默退出应用，只在主 widget 中有效。当为 false 时，引擎会弹出对话框询问是否退出应用
            retData: {name:'closeWidget'},
            animation: {
                type: 'flip',
                subType: 'from_bottom',
                duration: 500
            }
        });
    });
}
//单击确认退出
function clickConfigExitApp(){
    api.addEventListener({
        name: 'keyback'
    }, function(ret, err) {
        api.closeWidget({
            id: api.appId, //这里改成自己的应用ID
            silent: false,//描述：（可选项）是否静默退出应用，只在主 widget 中有效。当为 false 时，引擎会弹出对话框询问是否退出应用
            retData: {name:'closeWidget'},
            animation: {
                type: 'flip',
                subType: 'from_bottom',
                duration: 500
            }
        });
    });
}